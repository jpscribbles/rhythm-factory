    //add into eval code for performance tests


 let pulseGroup = "group"
    let PC = 8 


    //3 stages
    //define variables
    let varDef = []

    //create loop nests
    let full = []
    let pushed = ""
    let closer = ""

    //combine arrays
	//fix group1 concat it gets used twice
    let arrcat = ["\nlet RAW = group1.concat("]


    
    for (let i = 1; i <= PC; i++){
      //define variables
      varDef.push(`let group${i} = []`)

      //loop nesting
      pushed += "${i" + i + "}"
      full.push(`    
for (let i${i} = VC; i${i} >= 0; i${i}--) {
group${i}.push(` + "`" + pushed + "`)")


      //count loop closings
      closer += `}\n`

      //count array groups
      arrcat.push(`group${i},`)

    }


//closing loop nest and array concat
    full.push(closer)
    arrcat.push(")")

    //creating code here
    stamp.value = 
      varDef.join("\n") 
      + "\nlet VC = 1\n" 

      + full.join("\n")
      + arrcat.join("\n")




//16 pulses

let group1 = []
let group2 = []
let group3 = []
let group4 = []
let group5 = []
let group6 = []
let group7 = []
let group8 = []
let group9 = []
let group10 = []
let group11 = []
let group12 = []
let group13 = []
let group14 = []
let group15 = []
let group16 = []
let VC = 1
    
for (let i1 = VC; i1 >= 0; i1--) {
group1.push(`${i1}`)
    
for (let i2 = VC; i2 >= 0; i2--) {
group2.push(`${i1}${i2}`)
    
for (let i3 = VC; i3 >= 0; i3--) {
group3.push(`${i1}${i2}${i3}`)
    
for (let i4 = VC; i4 >= 0; i4--) {
group4.push(`${i1}${i2}${i3}${i4}`)
    
for (let i5 = VC; i5 >= 0; i5--) {
group5.push(`${i1}${i2}${i3}${i4}${i5}`)
    
for (let i6 = VC; i6 >= 0; i6--) {
group6.push(`${i1}${i2}${i3}${i4}${i5}${i6}`)
    
for (let i7 = VC; i7 >= 0; i7--) {
group7.push(`${i1}${i2}${i3}${i4}${i5}${i6}${i7}`)
    
for (let i8 = VC; i8 >= 0; i8--) {
group8.push(`${i1}${i2}${i3}${i4}${i5}${i6}${i7}${i8}`)
    
for (let i9 = VC; i9 >= 0; i9--) {
group9.push(`${i1}${i2}${i3}${i4}${i5}${i6}${i7}${i8}${i9}`)
    
for (let i10 = VC; i10 >= 0; i10--) {
group10.push(`${i1}${i2}${i3}${i4}${i5}${i6}${i7}${i8}${i9}${i10}`)
    
for (let i11 = VC; i11 >= 0; i11--) {
group11.push(`${i1}${i2}${i3}${i4}${i5}${i6}${i7}${i8}${i9}${i10}${i11}`)
    
for (let i12 = VC; i12 >= 0; i12--) {
group12.push(`${i1}${i2}${i3}${i4}${i5}${i6}${i7}${i8}${i9}${i10}${i11}${i12}`)
    
for (let i13 = VC; i13 >= 0; i13--) {
group13.push(`${i1}${i2}${i3}${i4}${i5}${i6}${i7}${i8}${i9}${i10}${i11}${i12}${i13}`)
    
for (let i14 = VC; i14 >= 0; i14--) {
group14.push(`${i1}${i2}${i3}${i4}${i5}${i6}${i7}${i8}${i9}${i10}${i11}${i12}${i13}${i14}`)
    
for (let i15 = VC; i15 >= 0; i15--) {
group15.push(`${i1}${i2}${i3}${i4}${i5}${i6}${i7}${i8}${i9}${i10}${i11}${i12}${i13}${i14}${i15}`)
    
for (let i16 = VC; i16 >= 0; i16--) {
group16.push(`${i1}${i2}${i3}${i4}${i5}${i6}${i7}${i8}${i9}${i10}${i11}${i12}${i13}${i14}${i15}${i16}`)
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}

let RAW = group1.concat(
group2,
group3,
group4,
group5,
group6,
group7,
group8,
group9,
group10,
group11,
group12,
group13,
group14,
group15,
group16,
)



//4 pulse count
let group1 = []
let group2 = []
let group3 = []
let group4 = []
let VC = 1
    
for (let i1 = VC; i1 >= 0; i1--) {
group1.push(`${i1}`)
    
for (let i2 = VC; i2 >= 0; i2--) {
group2.push(`${i1}${i2}`)
    
for (let i3 = VC; i3 >= 0; i3--) {
group3.push(`${i1}${i2}${i3}`)
    
for (let i4 = VC; i4 >= 0; i4--) {
group4.push(`${i1}${i2}${i3}${i4}`)
}
}
}
}

let RAW = group1.concat(
group2,
group3,
group4,
)




//8 pulse
let group1 = []
let group2 = []
let group3 = []
let group4 = []
let group5 = []
let group6 = []
let group7 = []
let group8 = []
let VC = 1
    
for (let i1 = VC; i1 >= 0; i1--) {
group1.push(`${i1}`)
    
for (let i2 = VC; i2 >= 0; i2--) {
group2.push(`${i1}${i2}`)
    
for (let i3 = VC; i3 >= 0; i3--) {
group3.push(`${i1}${i2}${i3}`)
    
for (let i4 = VC; i4 >= 0; i4--) {
group4.push(`${i1}${i2}${i3}${i4}`)
    
for (let i5 = VC; i5 >= 0; i5--) {
group5.push(`${i1}${i2}${i3}${i4}${i5}`)
    
for (let i6 = VC; i6 >= 0; i6--) {
group6.push(`${i1}${i2}${i3}${i4}${i5}${i6}`)
    
for (let i7 = VC; i7 >= 0; i7--) {
group7.push(`${i1}${i2}${i3}${i4}${i5}${i6}${i7}`)
    
for (let i8 = VC; i8 >= 0; i8--) {
group8.push(`${i1}${i2}${i3}${i4}${i5}${i6}${i7}${i8}`)
}
}
}
}
}
}
}
}

let RAW = group1.concat(
group2,
group3,
group4,
group5,
group6,
group7,
group8,
)








