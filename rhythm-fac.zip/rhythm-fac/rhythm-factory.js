
//pulse counter
let pulse = [];

for (let i = 0; i < RAW.length; i++) {
  pulse.push(RAW[i].length)
}


//beat counter
let beat = [];

for (let i = 0; i < RAW.length; i++) {
  let bag = []
  for (let j = 0; j < RAW[i].length; j++) {
    if (RAW[i][j] == 1) {
      bag.push(1)
    }
  }
  beat.push(bag.length)
}


//starting point: downbeat or syncopation
let start = [];

for (let i = 0; i < RAW.length; i++) {
  if (RAW[i][0] == 1) {
    start.push("Downbeat")
  }
  else if (RAW[i][0] == 0) {
    start.push("Syncopated")
  }
}


//rhythm illustration
let paint =
  RAW.map(a => a
    .replace(/0/g, `⚪`)
    .replace(/1/g, `⚫`) 
  )


//inverse
let inverse =
  RAW.map(a => a
    .replace(/0/g, `o`)
    .replace(/1/g, `0`)
	.replace(/o/g, `1`)	  
  )


//reflection or mirror
let mirror = 
    RAW.map(a => a
            .split("")
            .reverse()
            .join("")
           )


//palindrome or the same forwards as backwards
let palindrome = 
	RAW.map((a, i) => a == mirror[i])



//NEW PAGE
//NEED TO FIX relationship between e and sorting, possible to replace e later with subscript HTML element, 
//change eVarcounte, something easy to for regex
//why are there duplicates for first of alpha factory rhythm
//be careful using sort for strings, may be different for "4" vs 4 number.
//Code is being mutated so [...] is needed, may change to functional setup later



    //whole number array
    let RAW2 = [...RAW]

    for (let varCount = 8; 0 < varCount; varCount--) {
      RAW2 = RAW2.map(a => a
                      .replace(new RegExp(`1${"0".repeat(varCount - 1)}`, "g"), varCount))

    }

    //why does starting on 7 in regex fail
    for (let varCount = 8; 0 < varCount; varCount--) {
      RAW2 = RAW2.map(a => a
                      .replace(new RegExp(`${"0".repeat(varCount)}`, "g"), `s${varCount}e`))

    }




    //compositions (with syncopations)
    for (let i = 0; i < RAW2.length; i++) {
      let bag;
      if (RAW2[i][0] == "s") {
        bag = RAW2[i].split("")
        bag[bag.length - 1] = (bag.slice(bag.indexOf("s") + 1, bag.indexOf("e")) * 1) + (bag[bag.length - 1] * 1)
        RAW2[i] = bag.join("")

      }
    }


    //partitions sorted
    let partition = [...RAW2]

    for (let i = 0; i < partition.length; i++) {
      let bag;
      if (partition[i][0] == "s") {

        partition[i] = partition[i]
          .replace(/(s\d*e)/g, "")
          .split("")
          .sort((a, b) => b - a)
          .join("")
      }

      else {

        partition[i] =  partition[i]
          .split("")
          .sort((a, b) => b - a)
          .join("")
      }
    }


    //composition group
    let compositionGroup = [...RAW2]

    for (let i = 0; i < compositionGroup.length; i++) {
      let bag;
      if (compositionGroup[i][0] == "s") {

        compositionGroup[i] = compositionGroup[i]
          .replace(/(s\d*e)/g, "")

      }
    }

    //necklace
    let compGroup = [...compositionGroup]

    let necklace = []
    for (let i = 0; i < compGroup.length; i++) {

      for (let j = 0; j < compGroup.length; j++) {


        if (partition[i] == partition[j]) {

          if (compGroup[i] == compGroup[j]) {
            necklace.push(compGroup[i])
            return
          }

          for (let k = 0; k < compGroup[i].length; k++) {
            let bag;
            bag = compGroup[j].split("")
            bag.push(bag[0]).shift()
            if (compGroup[i] == bag) {
              necklace.push(compGroup[i])
              return
            }
          }
        }
      }
    }




	
 //musical notes
    let muse = [...RAW]

    let note = [
      "s","e","e.","q",
      "q-s","q.","q","h"
    ]
    let rest = [
      "S","E","E.","Q",
      "Q_S","Q.","Q","H"
    ]

    for (let varCount = 8; 0 < varCount; varCount--) {
      muse = muse.map(a => a
                      .replace(new RegExp(`1${"0".repeat(varCount - 1)}`, "g"), note[varCount - 1]))

    }

    //why does starting on 7 in regex fail
    for (let varCount = 8; 0 < varCount; varCount--) {
      muse = muse.map(a => a
                      .replace(new RegExp(`${"0".repeat(varCount)}`, "g"), rest[varCount - 1]))

    }
























